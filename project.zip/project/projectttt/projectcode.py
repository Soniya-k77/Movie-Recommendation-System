import pandas as pd
import tkinter as tk
from tkinter import messagebox

df2 = pd.read_csv("movieprj.csv.xls")
df2["overview"] = df2["overview"].fillna("")
def show_popular():
    movie_listbox.delete(0, tk.END)
    top_movies = df2.sort_values(by="popularity", ascending=False).head(15)

    for index, row in top_movies.iterrows():
        movie_listbox.insert(tk.END, row["original_title"])

def search_keyword():
    movie_listbox.delete(0, tk.END)
    user_word = input_entry.get()

    if user_word == "":
        messagebox.showwarning("Warning", "Please enter a word")
        return
    results = df2[df2["overview"].str.contains(user_word, case=False, na=False)]

    if results.empty:
        movie_listbox.insert(tk.END, "No movies found.")
    else:
        top_matches = results.sort_values(by="popularity", ascending=False).head(15)

        for index, row in top_matches.iterrows():
            movie_listbox.insert(tk.END, row["original_title"])

window = tk.Tk()
window.title("Movie Project")
window.geometry("500x400")
window.configure(bg="skyblue4")

label1 = tk.Label(window, text="🎬 Movie Recommendation System",font=("Ariql",39,"bold"),bg="gray",fg="black")
label1.pack()

btn1 = tk.Button(window, text="Show Top Popular Movies", command=show_popular,font=("Candara Light",20,"bold"),bg="green",fg="white")
btn1.pack()

label2 = tk.Label(window, text="Enter a keyword to search:",font="20")
label2.pack()

input_entry = tk.Entry(window,font="50",bg="white")
input_entry.pack()

btn2 = tk.Button(window, text="Search Movies", command=search_keyword,font=("Ariql",12,"bold"),bg="deep sky blue",fg="black")
btn2.pack()

label3 = tk.Label(window, text="Results:",font=("Ariql",15),bg="white",fg="black")
label3.pack()

movie_listbox = tk.Listbox(window,width=30, height=15,font=("Ariql",15,"bold"),fg="black",bg="ivory3")
movie_listbox.pack()
window.mainloop()